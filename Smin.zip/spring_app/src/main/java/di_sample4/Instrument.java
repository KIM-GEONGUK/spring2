package di_sample4;

public interface Instrument {
	public void play();

}
