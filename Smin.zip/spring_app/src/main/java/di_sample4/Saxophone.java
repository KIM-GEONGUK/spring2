package di_sample4;

public class Saxophone implements Instrument {
	
	public Saxophone() {
		super();
	}
	@Override
	public void play() {
		System.out.println("섹소폰소리... 투투투... ");
	}

}
