package di_sample4;

public class Piano implements Instrument{
	public Piano() {
		super();
	}
	
	public void play() {
		System.out.println(" 피아노소리 플린트 플린트... ");
	}
}
