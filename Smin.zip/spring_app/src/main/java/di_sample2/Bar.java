package di_sample2;

public class Bar {
	public void bar() {
		System.out.println(" Foo에 삽입할 bar bar bar");
	}
}
