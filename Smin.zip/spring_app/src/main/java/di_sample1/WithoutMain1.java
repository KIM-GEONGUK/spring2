package di_sample1;

public class WithoutMain1 {

	public static void main(String[] args) {
		// 객체 인스턴트화
		Performer duke = new Juggler(15);
		duke.perform();

	}

}
