package di_sample1;

public interface Performer {
   // 메소드 정의
   void perform();
}
