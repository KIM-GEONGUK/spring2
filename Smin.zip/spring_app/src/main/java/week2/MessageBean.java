package week2;

public class MessageBean {
	public void sayHello(String name) {
		System.out.println("hello" + name + "!");
		

	}

}
