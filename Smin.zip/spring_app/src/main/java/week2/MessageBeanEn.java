package week2;

public class MessageBeanEn implements MessageBean1{

	public void sayHello(String name) {
		System.out.println("Hello" + name + "!");

	}

}
