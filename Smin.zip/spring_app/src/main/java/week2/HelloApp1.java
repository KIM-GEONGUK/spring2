package week2;

public class HelloApp1 {

	public static void main(String[] args) {
		
		MessageBean bean = new MessageBean();
		bean.sayHello("spring");
		// TODO Auto-generated method stub

	}

}
