package week2;

public class HelloApp2 {

	public static void main(String[] args) {
		
		MessageBean1 bean = new MessageBeanEn();
		bean.sayHello("sprint");
		// TODO Auto-generated method stub

	}

}
