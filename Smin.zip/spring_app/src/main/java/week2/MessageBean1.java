package week2;

public interface MessageBean1 {
	public void sayHello(String name);
	
}
