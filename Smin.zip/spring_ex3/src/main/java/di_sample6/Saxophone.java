package di_sample6;

public class Saxophone implements Instrument {
	public Saxophone() {
		super();
	}
	public void play() {
		System.out.println("섹소폰 소리 Toot Toot...");
	}

}
