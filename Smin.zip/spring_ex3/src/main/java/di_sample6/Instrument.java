package di_sample6;

public interface Instrument {
	// 메소드 정의
	// 피아노, 섹소폰 같이 사용한 메소드 정의
	public void play();
	
}
