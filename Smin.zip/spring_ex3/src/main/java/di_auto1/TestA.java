package di_auto1;

public class TestA {
	private TestB b;
	private TestC c;
	
	//setter / getter 메소드
	public TestB getB() {
		return b;
	}
	public void setB(TestB b) {
		this.b = b;
	}
	public TestC getC() {
		return c;
	}
	public void setC(TestC c) {
		this.c = c;
	}
	
	
}
