package di_auto1;

public class TestB {
	
	public void display() {
		System.out.println("TEST B 출력");
		
	}
}
