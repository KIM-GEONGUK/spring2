package di_auto2;

public class TestC {
	public void display() {
		System.out.println("TEST C 출력");
		
	}
}
